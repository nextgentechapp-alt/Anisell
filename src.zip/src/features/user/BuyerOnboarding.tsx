import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/context/AuthContext';
import { ROUTES } from '@/constants/routes';
import { Input } from '@/components/ui/Input';
import styles from './BuyerOnboarding.module.css';
import type { Address } from '@/types';

/**
 * Dedicated Customer Onboarding Hub.
 * Requires mandatory profile parameters before accessing the platform.
 */
const BuyerOnboarding: React.FC = () => {
   const { user, updateProfile } = useAuth();
   const navigate = useNavigate();
   
   const [formData, setFormData] = useState({
      phone: '',
      dateOfBirth: '',
      gender: '',
      addressLine: '',
      locality: '',
      city: '',
      state: '',
      pincode: ''
   });
   
   const [status, setStatus] = useState<string | null>(null);
   const [error, setError] = useState<string>('');

   const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
      setFormData(prev => ({ ...prev, [e.target.name]: e.target.value }));
   };

   const handleCompleteRegistration = async () => {
      setError('');
      if (!formData.phone || !formData.dateOfBirth || !formData.city || !formData.pincode) {
         return setError('Please complete all required fields (Phone, DOB, City, Pincode).');
      }

      setStatus('Finalizing buyer profile...');
      try {
         const newAddress: Address = {
            name: user?.displayName || 'Home',
            phone: formData.phone,
            addressLine: formData.addressLine,
            locality: formData.locality,
            city: formData.city,
            state: formData.state,
            pincode: formData.pincode,
            type: 'home'
         };

         await updateProfile({
            phone: formData.phone,
            dateOfBirth: formData.dateOfBirth,
            gender: formData.gender,
            addresses: [newAddress]
         });
         
         navigate(ROUTES.USER_PROFILE);
      } catch (err: any) { 
         setError(`Synchronization Failed: ${err.message}`); 
         setStatus(null); 
      }
   };

   return (
      <div className={styles.container}>
         <div className={styles.header}>
            <h1 className={styles.title}>Welcome, {user?.displayName}</h1>
            <p className={styles.subtitle}>Complete your profile setup to start acquiring premium pet listings.</p>
         </div>

         {error && <div className={styles.error}>{error}</div>}

         <div className={styles.formSection}>
            <h3 className={styles.sectionTitle}>1. Personal Information</h3>
            <div className={styles.inputGrid} style={{ gridTemplateColumns: '1fr', gap: '16px' }}>
               <Input label="Phone Number *" name="phone" value={formData.phone} onChange={handleInputChange} />
               <Input label="Date of Birth *" name="dateOfBirth" type="date" value={formData.dateOfBirth} onChange={handleInputChange} />
               <div style={{ display: 'flex', flexDirection: 'column', gap: '8px' }}>
                  <label style={{ fontSize: '14px', fontWeight: 600, color: '#334155' }}>Gender</label>
                  <select name="gender" value={formData.gender} onChange={handleInputChange} style={{ padding: '12px 16px', borderRadius: '12px', border: '1px solid #cbd5e1', outline: 'none', background: '#fff' }}>
                     <option value="">Select Gender</option>
                     <option value="male">Male</option>
                     <option value="female">Female</option>
                     <option value="other">Other</option>
                  </select>
               </div>
            </div>
         </div>

         <div className={styles.formSection}>
            <h3 className={styles.sectionTitle}>2. Primary Hub Location</h3>
            <div className={styles.inputGrid} style={{ gridTemplateColumns: '1fr 1fr', gap: '16px' }}>
               <div style={{ gridColumn: '1 / -1' }}>
                  <Input label="Address Line" name="addressLine" value={formData.addressLine} onChange={handleInputChange} />
               </div>
               <Input label="Locality" name="locality" value={formData.locality} onChange={handleInputChange} />
               <Input label="City *" name="city" value={formData.city} onChange={handleInputChange} />
               <Input label="State" name="state" value={formData.state} onChange={handleInputChange} />
               <Input label="Pincode *" name="pincode" value={formData.pincode} onChange={handleInputChange} />
            </div>
         </div>

         <button className={styles.submitBtn} disabled={!!status} onClick={handleCompleteRegistration}>
            {status || 'Complete Setup'}
         </button>
      </div>
   );
};

export default BuyerOnboarding;
