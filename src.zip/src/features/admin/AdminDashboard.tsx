import React, { useMemo } from 'react';
import { useSearchData } from '@/hooks/useSearchData';
import { AdminOverview } from '@/features/admin/AdminOverview';
import { Loading } from '@/components/common/Loading';
import type { Product, Seller, User } from '@/types';

/**
 * Admin Dashboard - Platform Governance.
 * Orchestrates platform administration, providing high-fidelity oversight into performance, 
 * identities, and inquiries.
 * Refactored to act as a strict 'Overview' hub, delegating deeper management features to dedicated router endpoints.
 */
const AdminDashboard: React.FC = () => {
  const { products, sellers, users, loading } = useSearchData();

  // Derive specialized analytics core for the overview feature
  const analytics = useMemo(() => {
    const typedSellers = sellers as Seller[];
    const typedProducts = products as Product[];
    
    const totalRevenue = typedSellers.reduce((acc, s) => acc + (s.analytics?.revenue || 0), 0);
    const totalSales = typedSellers.reduce((acc, s) => acc + (s.analytics?.totalSales || 0), 0);
    const totalViews = typedSellers.reduce((acc, s) => acc + (s.analytics?.storeViews || 0), 0);
    const totalReviews = typedProducts.reduce((acc, p) => acc + (p.productReviews?.length || 0), 0);
    
    const topProducts = [...typedProducts]
      .filter(p => (p.newSalesCount || 0) > 0)
      .sort((a, b) => (b.newSalesCount || 0) - (a.newSalesCount || 0));

    return {
      totalRevenue,
      totalSales,
      totalViews,
      totalReviews,
      topProducts,
      pendingInquiries: 0
    };
  }, [products, sellers]);

  if (loading) return <Loading fullScreen={false} />;

  return (
    <div className="admin-dashboard-content">
      <header style={{ marginBottom: '32px', display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end' }}>
        <div>
           <h1 style={{ fontSize: '28px', fontWeight: 800, color: '#1e293b', marginBottom: '8px' }}>Governance Oversight</h1>
           <p style={{ color: '#64748b', fontSize: '15px' }}>Real-time metrics and administration for the AniSell marketplace.</p>
        </div>
      </header>

      {/* Portal Operational Views */}
      <AdminOverview 
        products={products as Product[]}
        sellers={sellers as Seller[]}
        users={users as User[]}
        analytics={analytics}
      />
    </div>
  );
};

export default AdminDashboard;

