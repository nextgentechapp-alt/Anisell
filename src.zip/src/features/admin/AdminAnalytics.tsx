import React from 'react';
import { useSearchData } from '@/hooks/useSearchData';
import { Loading } from '@/components/common/Loading';
import { FiTrendingUp, FiPieChart, FiBarChart2 } from 'react-icons/fi';

/**
 * High-Fidelity Infrastructure Analytics.
 * Serves macro-level market trend analysis and performance metrics visualization.
 */
const AdminAnalytics: React.FC = () => {
  const { loading } = useSearchData();

  if (loading) return <Loading fullScreen={false} />;

  return (
    <div className="admin-dashboard-content">
      <header style={{ marginBottom: '32px', display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end' }}>
        <div>
           <h1 style={{ fontSize: '28px', fontWeight: 800, color: '#1e293b', marginBottom: '8px' }}>Platform Analytics</h1>
           <p style={{ color: '#64748b', fontSize: '15px' }}>Extrapolate macroscopic velocity curves, user growth engines, and registry metrics.</p>
        </div>
        <button style={{ padding: '10px 20px', background: '#f8fafc', color: '#0f172a', border: '1px solid #e2e8f0', borderRadius: '8px', fontWeight: 600, display: 'flex', alignItems: 'center', gap: '8px' }}>
           <FiPieChart /> Export Sync Data
        </button>
      </header>

      {/* Abstracted Chart Visualizers (Representational Layer) */}
      <div style={{ display: 'grid', gridTemplateColumns: 'minmax(0, 1.5fr) minmax(0, 1fr)', gap: '24px' }}>
        
         <div style={{ background: '#fff', padding: '32px', borderRadius: '16px', border: '1px solid #e2e8f0', boxShadow: '0 4px 6px -1px rgba(0,0,0,0.05)' }}>
            <h3 style={{ fontSize: '18px', fontWeight: 700, margin: '0 0 8px 0', color: '#1e293b', display: 'flex', alignItems: 'center', gap: '8px' }}><FiTrendingUp color="#3b82f6"/> 30-Day GMV Curve</h3>
            <p style={{ fontSize: '14px', color: '#64748b', marginBottom: '32px' }}>Gross Revenue mapped across daily aggregate pipelines.</p>
            <div style={{ height: '300px', display: 'flex', alignItems: 'flex-end', gap: '12px', paddingBottom: '20px', borderBottom: '1px solid #e2e8f0' }}>
               {[20, 30, 25, 45, 35, 55, 65, 45, 75, 85, 70, 100].map((v, i) => (
                 <div key={i} style={{ flex: 1, background: '#3b82f6', height: `${v}%`, borderRadius: '4px 4px 0 0', opacity: i === 11 ? 1 : 0.6 }} />
               ))}
            </div>
         </div>

         <div style={{ display: 'flex', flexDirection: 'column', gap: '24px' }}>
            <div style={{ background: '#fff', padding: '32px', borderRadius: '16px', border: '1px solid #e2e8f0', flex: 1 }}>
               <h3 style={{ fontSize: '18px', fontWeight: 700, margin: '0 0 8px 0', color: '#1e293b', display: 'flex', alignItems: 'center', gap: '8px' }}><FiBarChart2 color="#10b981" /> Identity Growth Stream</h3>
               <p style={{ fontSize: '14px', color: '#64748b', marginBottom: '24px' }}>Daily new global participants joining the network.</p>
               <div style={{ display: 'flex', flexDirection: 'column', gap: '16px' }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                     <span style={{ fontWeight: 600, color: '#475569' }}>Total Network Scale</span>
                     <span style={{ fontWeight: 700, color: '#10b981' }}>+43.2% ▲</span>
                  </div>
                  <div style={{ width: '100%', height: '8px', background: '#f1f5f9', borderRadius: '4px', overflow: 'hidden' }}>
                     <div style={{ width: '75%', height: '100%', background: '#10b981' }} />
                  </div>
               </div>
            </div>
            
            <div style={{ background: '#fff', padding: '32px', borderRadius: '16px', border: '1px solid #e2e8f0', flex: 1 }}>
               <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '100%' }}>
                  <div style={{ textAlign: 'center' }}>
                     <div style={{ fontSize: '48px', fontWeight: 800, color: '#1e293b' }}>84%</div>
                     <div style={{ fontSize: '14px', color: '#64748b', fontWeight: 600, textTransform: 'uppercase', letterSpacing: '1px', marginTop: '8px' }}>Global Listing Conversion</div>
                  </div>
               </div>
            </div>
         </div>

      </div>
    </div>
  );
};

export default AdminAnalytics;
