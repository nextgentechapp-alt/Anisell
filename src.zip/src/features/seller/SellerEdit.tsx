import React from 'react';
import { FiEdit3 } from 'react-icons/fi';
import { useAuth } from '@/context/AuthContext';

/**
 * Merchant Profile Editing Hub.
 * Manages store branding, contact logic, and global operation details.
 */
const SellerEdit: React.FC = () => {
  const { user, sellerData } = useAuth();

  return (
    <div className="seller-dashboard-content">
      <header style={{ marginBottom: '32px' }}>
        <h2 style={{ fontSize: '24px', fontWeight: 800, color: '#1e293b', marginBottom: '8px' }}>Store Profile</h2>
        <p style={{ color: '#64748b', fontSize: '15px' }}>Configure your storefront identity and core operational details.</p>
      </header>

      <div style={{ padding: '40px 20px', background: '#fff', borderRadius: '16px', border: '1px solid #e2e8f0' }}>
         <div style={{ display: 'flex', alignItems: 'center', gap: '24px', marginBottom: '32px' }}>
            <img 
               src={user?.photoURL || 'https://www.w3schools.com/howto/img_avatar.png'} 
               alt="" 
               style={{ width: '80px', height: '80px', borderRadius: '50%', objectFit: 'cover', border: '2px solid #e2e8f0' }} 
            />
            <div>
               <h3 style={{ margin: '0 0 4px 0', fontSize: '20px', fontWeight: 700 }}>{sellerData?.shopName || user?.displayName || 'Merchant Partner'}</h3>
               <p style={{ color: '#64748b', margin: 0 }}>Verified Store</p>
            </div>
            <button className="button-base button-outline" style={{ marginLeft: 'auto', display: 'flex', alignItems: 'center', gap: '8px' }}>
              <FiEdit3 /> Edit Store Logo
            </button>
         </div>

         <div style={{ display: 'grid', gridTemplateColumns: 'minmax(0, 1fr) minmax(0, 1fr)', gap: '20px' }}>
            <div>
               <label style={{ display: 'block', fontSize: '13px', fontWeight: 700, color: '#475569', marginBottom: '8px', textTransform: 'uppercase' }}>Store Name</label>
               <input type="text" readOnly value={sellerData?.shopName || user?.displayName || ''} style={{ width: '100%', padding: '12px 16px', borderRadius: '8px', border: '1px solid #cbd5e1', background: '#f8fafc', color: '#64748b' }} />
            </div>
            <div>
               <label style={{ display: 'block', fontSize: '13px', fontWeight: 700, color: '#475569', marginBottom: '8px', textTransform: 'uppercase' }}>Contact Email</label>
               <input type="email" readOnly value={user?.email || ''} style={{ width: '100%', padding: '12px 16px', borderRadius: '8px', border: '1px solid #cbd5e1', background: '#f8fafc', color: '#64748b' }} />
            </div>
            <div>
               <label style={{ display: 'block', fontSize: '13px', fontWeight: 700, color: '#475569', marginBottom: '8px', textTransform: 'uppercase' }}>Store Contact Number</label>
               <input type="text" readOnly value={user?.phone || 'Not provided'} style={{ width: '100%', padding: '12px 16px', borderRadius: '8px', border: '1px solid #cbd5e1', background: '#f8fafc', color: '#64748b' }} />
            </div>
            <div>
               <label style={{ display: 'block', fontSize: '13px', fontWeight: 700, color: '#475569', marginBottom: '8px', textTransform: 'uppercase' }}>Primary Hub Location</label>
               <input type="text" readOnly value={user?.addresses?.[0]?.city || 'Pending configuration'} style={{ width: '100%', padding: '12px 16px', borderRadius: '8px', border: '1px solid #cbd5e1', background: '#f8fafc', color: '#64748b' }} />
            </div>
         </div>
         
         <div style={{ marginTop: '32px', display: 'flex', justifyContent: 'flex-end' }}>
            <button className="button-base button-primary" disabled style={{ opacity: 0.7 }}>Update Store Branding</button>
         </div>
      </div>
    </div>
  );
};

export default SellerEdit;
