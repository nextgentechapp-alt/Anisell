import React from 'react';
import { FiTrendingUp, FiShoppingBag, FiStar, FiBarChart2, FiClock } from 'react-icons/fi';
import type { Seller, Product } from '@/types';
import { StatCard } from '@/components/ui/StatCard';
import styles from './SellerHome.module.css';

interface SellerHomeProps {
  seller: Seller;
  products: Product[];
}

/**
 * Seller Dashboard Home Feature.
 * Orchestrates merchant-branded visualizations for store analytics, revenue trends, 
 * and top-performing Listings through a scoped styling architectural layer.
 */
export const SellerHome: React.FC<SellerHomeProps> = ({ seller, products }) => {
  const analytics = seller.analytics || {
    totalSales: 0, revenue: 0, storeViews: 0, conversion: 0, storeRating: 0, salesHistory: [0,0,0,0,0,0,0]
  };

  const topProducts = products
    .filter(p => (p.newSalesCount || 0) > 0)
    .sort((a, b) => (b.newSalesCount || 0) - (a.newSalesCount || 0))
    .slice(0, 3);

  return (
    <div className={styles.container}>
      
      {/* Verification Pendancy Banner */}
      {seller.status === 'pending' && (
        <div style={{ background: '#fefce8', border: '1px solid #fef08a', padding: '16px 24px', borderRadius: '12px', marginBottom: '32px', display: 'flex', alignItems: 'center', gap: '16px' }}>
           <FiClock size={24} color="#ca8a04" />
           <div>
              <h3 style={{ margin: '0 0 4px 0', fontSize: '16px', fontWeight: 700, color: '#854d0e' }}>Storefront Under Administrative Review</h3>
              <p style={{ margin: 0, fontSize: '14px', color: '#a16207' }}>Your credentials and shop media have been successfully submitted during onboarding. You will be notified once a Platform Administrator authorizes your account to begin trading.</p>
           </div>
        </div>
      )}

      {/* 1. Merchant KPI Metrics - Core Dashboard Hub */}
      <div className={styles.kpiGrid}>
        <StatCard 
          label="Total Sales" 
          value={analytics.totalSales} 
          icon={<FiShoppingBag />} 
          color="#2563eb"
          variant="primary"
        />
        <StatCard 
          label="Store Views" 
          value={analytics.storeViews.toLocaleString()} 
          icon={<FiBarChart2 />} 
          color="#ea580c"
          variant="warning"
        />
        <StatCard 
          label="Gross Revenue" 
          value={`₹${analytics.revenue.toLocaleString()}`} 
          icon={<FiTrendingUp />} 
          color="#10b981"
          variant="success"
        />
        <StatCard 
          label="Conversion" 
          value={`${analytics.conversion}%`} 
          icon={<FiStar />} 
          color="#7c3aed"
          variant="neutral"
        />
      </div>

      {/* 2. Performance Tracking - 7 Day Trend */}
      {(() => {
        const recentHistory = (analytics.salesHistory || [0,0,0,0,0,0,0]).slice(-7);
        const maxHistory = Math.max(...recentHistory, 5); // Minimum scale floor
        const polylinePoints = recentHistory.map((val, i) => {
           const x = i * 150;
           const y = 240 - ((val / maxHistory) * 200);
           return `${x},${y}`;
        }).join(' ');

        return (
          <div className={styles.chartCard} style={{ background: '#fff', borderRadius: '16px', border: '1px solid #e2e8f0', padding: '24px', marginBottom: '32px' }}>
            <h3 className={styles.chartTitle} style={{ fontSize: '18px', fontWeight: 800, color: '#1e293b', margin: 0 }}>7-Day Sales Performance</h3>
            
            <div style={{ position: 'relative', width: '100%', height: '320px', marginTop: '32px' }}>
              <svg viewBox="50 0 800 300" style={{ width: '100%', height: '100%', overflow: 'visible' }}>
                 {/* Structural SVG Grid Lines */}
                 <line x1="0" y1="40" x2="800" y2="40" stroke="#f1f5f9" strokeWidth="1" />
                 <line x1="0" y1="140" x2="800" y2="140" stroke="#f1f5f9" strokeWidth="1" />
                 <line x1="0" y1="240" x2="800" y2="240" stroke="#e2e8f0" strokeWidth="2" />
                 
                 {/* Trajectory Data Line Graph */}
                 <polyline 
                   fill="none" 
                   stroke="#3b82f6" 
                   strokeWidth="4" 
                   strokeLinecap="round"
                   strokeLinejoin="round"
                   points={polylinePoints} 
                   style={{ filter: 'drop-shadow(0px 8px 12px rgba(59, 130, 246, 0.25))' }}
                 />
                 
                 {/* Node Interaction Points and Grid Labels */}
                 {recentHistory.map((val, i) => {
                    const x = i * 150;
                    const y = 240 - ((val / maxHistory) * 200);
                    return (
                      <g key={`point-${i}`}>
                        {val > 0 && <text x={x} y={y - 15} textAnchor="middle" fontSize="12" fill="#64748b" fontWeight="700">{val}</text>}
                        <circle cx={x} cy={y} r="6" fill="#fff" stroke="#2563eb" strokeWidth="3" style={{ transition: 'all 0.3s ease' }} />
                        <text x={x} y="280" textAnchor="middle" fontSize="13" fill="#64748b" fontWeight="600" style={{ letterSpacing: '0.5px' }}>D{i+1}</text>
                      </g>
                    );
                 })}
              </svg>
            </div>
          </div>
        );
      })()}

      {/* 3. Operational Discovery - Top Listings */}
      <div className={styles.topProductsCard}>
        <h3 className={styles.chartTitle}>Top Performing Listings</h3>
        <div className={styles.productList}>
          {topProducts.length > 0 ? topProducts.map(p => (
            <div key={p.productId} className={styles.productItem}>
              <img src={p.productMedia[0]} alt="" className={styles.productImage} />
              <div className={styles.productInfo}>
                <div className={styles.productName}>{p.productSubCategory}</div>
                <div className={styles.productMeta}>{p.productType} • Last 30 Days</div>
              </div>
              <div className={styles.productStats}>
                 <div className={styles.salesValue}>{p.newSalesCount} Items Sold</div>
              </div>
            </div>
          )) : (
            <p className={styles.productMeta} style={{ textAlign: 'center', padding: '24px' }}>
              No performance data captured for active listings yet.
            </p>
          )}
        </div>
      </div>
    </div>
  );
};
