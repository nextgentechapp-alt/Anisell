import React from 'react';
import { FiStar, FiMessageSquare } from 'react-icons/fi';

/**
 * Merchant Review Orchestrator.
 * Dedicated hub for analyzing and managing customer feedback.
 */
const SellerReviews: React.FC = () => {
  return (
    <div className="seller-dashboard-content">
      <header style={{ marginBottom: '32px' }}>
        <h2 style={{ fontSize: '24px', fontWeight: 800, color: '#1e293b', marginBottom: '8px' }}>Customer Reviews</h2>
        <p style={{ color: '#64748b', fontSize: '15px' }}>Analyze feedback and build trust with your marketplace participants.</p>
      </header>

      <div style={{ textAlign: 'center', padding: '60px 20px', background: '#fff', borderRadius: '16px', border: '2px dashed #e2e8f0' }}>
         <FiStar size={48} color="#cbd5e1" style={{ marginBottom: '16px' }} />
         <h3 style={{ margin: '0 0 8px 0', fontSize: '18px' }}>No Reviews Yet</h3>
         <p style={{ color: '#64748b', marginBottom: '24px' }}>Your store hasn't received any customer ratings or feedback.</p>
         <button 
           style={{ padding: '12px 24px', background: '#2563eb', color: '#fff', border: 'none', borderRadius: '10px', fontSize: '15px', fontWeight: 600, cursor: 'pointer', display: 'inline-flex', alignItems: 'center', gap: '8px' }}
         >
           <FiMessageSquare /> Request Reviews
         </button>
      </div>
    </div>
  );
};

export default SellerReviews;
