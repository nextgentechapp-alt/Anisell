import React, { createContext, useContext, useEffect, useState } from 'react';
import { 
  onAuthStateChanged, 
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  signInWithPopup, 
  signOut, 
  updateProfile as firebaseUpdateProfile
} from 'firebase/auth';
import { doc, getDoc, setDoc, updateDoc } from 'firebase/firestore';
import { auth, db, googleProvider } from '@/services/firebase/config';
import type { User, Seller } from '@/types';

interface AuthContextType {
  user: User | null;
  sellerData: Seller | null;
  loading: boolean;
  login: (email: string, pass: string) => Promise<User | null>;
  register: (email: string, pass: string, role: 'buyer' | 'seller') => Promise<void>;
  updateProfile: (data: Partial<User>) => Promise<void>;
  loginWithGoogle: (role: 'buyer' | 'seller') => Promise<{ user: User | null; sellerStatus?: string }>;
  logout: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

/**
 * Global Authentication Context Provider.
 * Synchronizes Firebase Auth state with the application's User profile in Firestore.
 */
export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [sellerData, setSellerData] = useState<Seller | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (firebaseUser) => {
      setLoading(true); // Ensure lockout while fetching
      try {
        if (firebaseUser) {
          // Fetch extended profile database document
          const userRef = doc(db, 'users', firebaseUser.uid);
          const userDoc = await getDoc(userRef);
          
          if (userDoc.exists()) {
            let userData = userDoc.data() as User;
            // Schema Validation: Ensure fallback arrays exist
            userData.addresses = userData.addresses || [];
            userData.orders = userData.orders || [];
            setUser(userData);

            // Conditional Deep Fetch for Merchant profiles
            if (userData.role === 'seller') {
              const sellerRef = doc(db, 'sellers', firebaseUser.uid);
              const sellerDoc = await getDoc(sellerRef);
              if (sellerDoc.exists()) {
                let sData = sellerDoc.data() as Seller;
                sData.productIds = sData.productIds || [];
                sData.analytics = sData.analytics || { totalSales: 0, revenue: 0, storeViews: 0, conversion: 0, storeRating: 0, salesHistory: [] };
                sData.status = sData.status || 'pending';
                setSellerData(sData);
              } else {
                setSellerData(null);
              }
            } else {
              setSellerData(null);
            }
          } else {
            setUser(null);
            setSellerData(null);
          }
        } else {
          setUser(null);
          setSellerData(null);
        }
      } catch (err) {
        console.error('Session Hydration Error:', err);
      } finally {
        setLoading(false);
      }
    });

    return () => unsubscribe();
  }, []);

  const login = async (email: string, pass: string) => {
    const result = await signInWithEmailAndPassword(auth, email, pass);
    const userRef = doc(db, 'users', result.user.uid);
    const userDoc = await getDoc(userRef);
    if (userDoc.exists()) {
      const userData = userDoc.data() as User;
      setUser(userData);
      return userData;
    }
    return null;
  };

  const register = async (email: string, pass: string, role: 'buyer' | 'seller') => {
    const result = await createUserWithEmailAndPassword(auth, email, pass);
    const userId = result.user.uid;
    const initialProfile = {
      uid: userId,
      email: email,
      role: role,
      displayName: result.user.displayName || 'New User',
      photoURL: result.user.photoURL || 'https://www.w3schools.com/howto/img_avatar.png',
      joinDate: new Date().toISOString()
    };
    await setDoc(doc(db, 'users', userId), initialProfile);
    setUser(initialProfile as User);
  };

  const updateProfile = async (data: Partial<User>) => {
    if (!auth.currentUser) return;
    const userRef = doc(db, 'users', auth.currentUser.uid);
    await updateDoc(userRef, data);
    
    // Update firebase user if display name/photo changed
    if (data.displayName || data.photoURL) {
      await firebaseUpdateProfile(auth.currentUser, {
        displayName: data.displayName,
        photoURL: data.photoURL
      });
    }

    setUser(prev => prev ? { ...prev, ...data } : null);
  };

  const loginWithGoogle = async (requestedRole: 'buyer' | 'seller'): Promise<{ user: User | null; sellerStatus?: string }> => {
    try {
      const result = await signInWithPopup(auth, googleProvider);
      const firebaseUser = result.user;
      
      const userRef = doc(db, 'users', firebaseUser.uid);
      const userSnap = await getDoc(userRef);
      
      let finalRole: 'buyer' | 'seller' | 'admin' = requestedRole;
      let finalUserData: User;

      if (!userSnap.exists()) {
        const initialProfile = {
          uid: firebaseUser.uid,
          email: firebaseUser.email || '',
          role: requestedRole,
          displayName: firebaseUser.displayName || 'New User',
          photoURL: firebaseUser.photoURL || 'https://www.w3schools.com/howto/img_avatar.png',
          joinDate: new Date().toISOString()
        };
        await setDoc(userRef, initialProfile);
        finalUserData = initialProfile as User;
      } else {
        const userData = userSnap.data() as User;
        if (requestedRole === 'seller' && userData.role === 'buyer') {
          await updateDoc(userRef, { role: 'seller' });
          userData.role = 'seller';
          finalRole = 'seller';
        } else {
          finalRole = userData.role;
        }
        finalUserData = userData;
      }

      let returnedSellerStatus: string | undefined;
      let finalSellerData: Seller | null = null;

      // Initialize the specialized Seller Identity if navigating the Merchant flow
      if (finalRole === 'seller') {
         const sellerRef = doc(db, 'sellers', firebaseUser.uid);
         const sellerSnap = await getDoc(sellerRef);
         if (!sellerSnap.exists()) {
            const newSellerProfile = {
               sellerId: firebaseUser.uid,
               sellerLocation: 'Pending Verification',
               sellerNumber: firebaseUser.phoneNumber || '',
               shopName: '', 
               sellerCertificateUrl: '',
               shopPhotoUrls: [],
               productIds: [],
               status: 'onboarding' as const, 
               analytics: { totalSales: 0, revenue: 0, storeViews: 0, conversion: 0, storeRating: 0, salesHistory: [] }
            };
            await setDoc(sellerRef, newSellerProfile);
            returnedSellerStatus = 'onboarding';
            finalSellerData = newSellerProfile;
         } else {
            returnedSellerStatus = sellerSnap.data()?.status;
            finalSellerData = sellerSnap.data() as Seller;
         }
      }
      
      // Concurrently overwrite the Null Context lock forced by the fast onAuthStateChanged race
      setUser(finalUserData);
      setSellerData(finalSellerData);

      return { user: finalUserData, sellerStatus: returnedSellerStatus };

    } catch (error) {
      console.error('Google Auth Error:', error);
      throw error;
    }
  };

  const logout = async () => {
    await signOut(auth);
    localStorage.removeItem('anisell_user_details');
    setUser(null);
    setSellerData(null);
  };

  return (
    <AuthContext.Provider value={{ user, sellerData, loading, login, register, updateProfile, loginWithGoogle, logout }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
